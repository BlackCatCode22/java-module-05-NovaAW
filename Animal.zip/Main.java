package gonzalez.zoo.com;

public class Main {
    public static void main(String[] args) {
        // Create multiple Animal objects
        Animal tiger = new Animal(
                "Male",          // sex
                5,               // age
                450,             // weight
                "Rajah",         // name
                "T001",          // ID
                "2020-05-12",    // birth date
                "Orange/Black",  // color
                "India",         // origin
                "2021-03-01"     // arrival date
        );

        Animal lion = new Animal(
                "Female",
                4,
                350,
                "Nala",
                "L001",
                "2021-07-09",
                "Golden",
                "Kenya",
                "2022-02-15"
        );

        Animal bear = new Animal(
                "Male",
                7,
                600,
                "Baloo",
                "B001",
                "2018-10-02",
                "Brown",
                "Canada",
                "2019-05-25"
        );

        Animal hyena = new Animal(
                "Female",
                3,
                120,
                "Shenzi",
                "H001",
                "2022-03-21",
                "Gray",
                "South Africa",
                "2023-06-10"
        );

        // Print all animals
        System.out.println("=== Zoo Animal Information ===\n");

        System.out.println(tiger);
        System.out.println(lion);
        System.out.println(bear);
        System.out.println(hyena);

        // Print total number of animals created
        System.out.println("Total Animals Created: " + Animal.numOfAnimals);
    }
}