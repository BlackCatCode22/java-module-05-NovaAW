package gonzalez.zoo.com;

import java.io.*;
import java.util.*;

public class App {

    public static void main(String[] args) {
        System.out.println("Welcome to my Zoo Program!");

        String nameFilePath = "animalNames.txt";
        String dataFilePath = "arrivingAnimals.txt";

        AnimalNameListsWrapper animalLists = Utilities.createAnimalNameLists(nameFilePath);

        ArrayList<String> hyenaNames = animalLists.getHyenaNameList();
        ArrayList<String> lionNames = animalLists.getLionNameList();
        ArrayList<String> tigerNames = animalLists.getTigerNameList();
        ArrayList<String> bearNames = animalLists.getBearNameList();

        ArrayList<Animal> zooAnimals = new ArrayList<>();
        HashMap<String, Integer> speciesCount = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(dataFilePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                String[] firstParts = parts[0].split(" ");

                int age = Integer.parseInt(firstParts[0]);
                String sex = firstParts[3];
                String species = firstParts[4].toLowerCase();

                String season = parts[1].split(" ")[2];
                String color = parts[2];
                int weight = Integer.parseInt(parts[3].replaceAll("[^0-9]", ""));
                String origin = parts[4] + ", " + parts[5];

                String animalID = Utilities.calcAnimalID(species);
                String birthDate = Utilities.calcAnimalBirthDate(age, season);
                String arrivalDate = Utilities.arrivalDate();
                String name = "";

                Animal animal = null;
                switch (species) {
                    case "hyena":
                        name = hyenaNames.remove(0);
                        animal = new Hyena(sex, age, weight, name, animalID, birthDate, color, origin, arrivalDate);
                        break;
                    case "lion":
                        name = lionNames.remove(0);
                        animal = new Lion(sex, age, weight, name, animalID, birthDate, color, origin, arrivalDate);
                        break;
                    case "tiger":
                        name = tigerNames.remove(0);
                        animal = new Tiger(sex, age, weight, name, animalID, birthDate, color, origin, arrivalDate);
                        break;
                    case "bear":
                        name = bearNames.remove(0);
                        animal = new Bear(sex, age, weight, name, animalID, birthDate, color, origin, arrivalDate);
                        break;
                    default:
                        System.out.println("Unknown species: " + species);
                }

                if (animal != null) {
                    zooAnimals.add(animal);
                    speciesCount.put(species, speciesCount.getOrDefault(species, 0) + 1);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading data file: " + e.getMessage());
        }

        System.out.println("\nZoo Animal Report:\n");
        zooAnimals.forEach(System.out::println);

        System.out.println("\nAnimal Species Count:");
        speciesCount.forEach((k, v) -> System.out.println(capitalize(k) + "s: " + v));
        System.out.println("Total Animals: " + Animal.numOfAnimals);
    }

    private static String capitalize(String str) {
        if (str == null || str.isEmpty()) return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
}