package gonzalez.zoo.com;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.*;
import java.util.ArrayList;

public class Utilities {

    public static String calcAnimalID(String species) {
        String prefix;
        int num;

        switch (species.toLowerCase()) {
            case "hyena":
                prefix = "Hy";
                num = Hyena.numOfHyenas + 1;
                break;
            case "lion":
                prefix = "Li";
                num = Lion.numOfLions + 1;
                break;
            case "tiger":
                prefix = "Ti";
                num = Tiger.numOfTigers + 1;
                break;
            case "bear":
                prefix = "Be";
                num = Bear.numOfBears + 1;
                break;
            default:
                return "XX00";
        }

        return prefix + String.format("%02d", num);
    }

    public static String arrivalDate() {
        return new SimpleDateFormat("yyyy-MM-dd").format(new Date());
    }

    public static String calcAnimalBirthDate(int age, String season) {
        int year = Integer.parseInt(new SimpleDateFormat("yyyy").format(new Date())) - age;
        switch (season.toLowerCase()) {
            case "spring": return year + "-03-21";
            case "summer": return year + "-06-21";
            case "fall": return year + "-09-21";
            case "winter": return year + "-12-21";
            default: return year + "-01-01";
        }
    }

    public static AnimalNameListsWrapper createAnimalNameLists(String filePath) {
        ArrayList<String> hyena = new ArrayList<>();
        ArrayList<String> lion = new ArrayList<>();
        ArrayList<String> tiger = new ArrayList<>();
        ArrayList<String> bear = new ArrayList<>();
        ArrayList<String> current = null;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.equalsIgnoreCase("Hyena Names:")) current = hyena;
                else if (line.equalsIgnoreCase("Lion Names:")) current = lion;
                else if (line.equalsIgnoreCase("Tiger Names:")) current = tiger;
                else if (line.equalsIgnoreCase("Bear Names:")) current = bear;
                else if (!line.isEmpty() && current != null) {
                    for (String name : line.split(",\\s*")) current.add(name);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading names file: " + e.getMessage());
        }
        return new AnimalNameListsWrapper(hyena, lion, tiger, bear);
    }
}