package gonzalez.zoo.com;

public class Animal {
    static int numOfAnimals = 0;

    private String sex;
    private int age;
    private int weight;
    private String animalName;
    private String animalID;
    private String animalBirthDate;
    private String animalColor;
    private String animalOrigin;
    private String animalArrivalDate;

    public Animal() {
        numOfAnimals++;
    }

    public Animal(String sex, int age, int weight, String animalName,
                  String animalID, String animalBirthDate, String animalColor,
                  String animalOrigin, String animalArrivalDate) {
        numOfAnimals++;
        this.sex = sex;
        this.age = age;
        this.weight = weight;
        this.animalName = animalName;
        this.animalID = animalID;
        this.animalBirthDate = animalBirthDate;
        this.animalColor = animalColor;
        this.animalOrigin = animalOrigin;
        this.animalArrivalDate = animalArrivalDate;
    }

    @Override
    public String toString() {
        return String.format(
                "Name: %s\nID: %s\nSex: %s\nAge: %d\nWeight: %d lbs\nColor: %s\nBirth Date: %s\nOrigin: %s\nArrival Date: %s\n",
                animalName, animalID, sex, age, weight, animalColor, animalBirthDate, animalOrigin, animalArrivalDate
        );
    }
}